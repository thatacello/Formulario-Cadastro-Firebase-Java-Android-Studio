package br.edu.infnet.formulariocadastrosalvandofirebase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_WRITE = 11;
    private static final int PERMISSION_READ = 12;

    private EditText edtName;
    private EditText edtPassword;
    private EditText edtEmail;
    private EditText edtPhone;
    private EditText edtCel;
    private EditText edtCPF;
    private EditText edtCity;

    private Button btnSave;
    private Button btnClean;
    private Button btnContactList;

    private User user;
    private FirebaseDatabase database;
    private DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        verificarPermissões();

        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("users");

        user = new User();

        edtName = (EditText) findViewById(R.id.edtName);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
        edtEmail = (EditText) findViewById(R.id.edtEmail);
        edtPhone = (EditText) findViewById(R.id.edtPhone);
        edtCel = (EditText) findViewById(R.id.edtCel);
        edtCPF = (EditText) findViewById(R.id.edtCPF);
        edtCity = (EditText) findViewById(R.id.edtCity);

        btnSave = (Button) findViewById(R.id.btnSave);
        btnClean = (Button) findViewById(R.id.btnClean);
        btnContactList = (Button) findViewById(R.id.btnContactList);

        //aplicando mascaras para os editTexts
        edtPhone.addTextChangedListener(MaskEditText.mask(edtPhone, MaskEditText.FORMAT_PHONE));
        edtCel.addTextChangedListener(MaskEditText.mask(edtCel, MaskEditText.FORMAT_CEL));
        edtCPF.addTextChangedListener(MaskEditText.mask(edtCPF, MaskEditText.FORMAT_CPF));

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validarFormulario();

                user.setName(edtName.getText().toString());
                user.setEmail(edtEmail.getText().toString());
                user.setPassword(edtPassword.getText().toString());
                user.setPhone(edtPhone.getText().toString());
                user.setCel(edtCel.getText().toString());
                user.setCPF(edtCPF.getText().toString());
                user.setCity(edtCity.getText().toString());

                inserirUserDatabase(user);

            }
        });

        btnClean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                apagarFormulario();
            }
        });

        btnContactList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirListaContatos();
            }
        });
    }

    private void apagarFormulario(){
        edtName.setText("");
        edtPassword.setText("");
        edtEmail.setText("");
        edtPhone.setText("");
        edtCel.setText("");
        edtCPF.setText("");
        edtCity.setText("");
    }

    private void validarFormulario(){
        if (edtName.getText().toString().equals("") ||
                edtPassword.getText().toString().equals("") ||
                edtEmail.getText().toString().equals("") ||
                edtPhone.getText().toString().equals("") ||
                edtCel.getText().toString().equals("") ||
                edtCPF.getText().toString().equals("") ||
                edtCity.getText().toString().equals("")){
            Toast.makeText(MainActivity.this, "Você deve preencher todos os campos!", Toast.LENGTH_SHORT).show();
        }
    }

    private void verificarPermissões (){

        // Copiado da documentação oficial solicitar permissoes em tempo de execução

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE) && ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.READ_EXTERNAL_STORAGE)) {

            } else {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        PERMISSION_WRITE);
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        PERMISSION_READ);

            }
        }

    }

    private void abrirListaContatos(){
        Intent i = new Intent(MainActivity.this, ListaContatos.class);
        startActivity(i);
    }

    private void inserirUserDatabase(User user){
        myRef = database.getReference("users");

        // o firebase gera uma key automatica para cada usuário
        //para que nao seja inserido usuarios repetidos

        String key = myRef.child("users").push().getKey();
        user.setKeyUser(key);
        myRef.child(key).setValue(user);

        Toast.makeText(MainActivity.this, "Cadastro efetuado!", Toast.LENGTH_LONG).show();
    }
}

