package br.edu.infnet.formulariocadastrosalvandofirebase;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    private List<User> mUserList;
    private Context context;
    private Dialog dialog;
    private DatabaseReference mDatabase;

    public Adapter(List<User> l, Context c){
        context = c;
        mUserList = l;
    }

    @NonNull
    @Override
    public Adapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.all, viewGroup, false);
        return new Adapter.ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder( Adapter.ViewHolder holder, int position) {

            final User item = mUserList.get(position);

            holder.txtName.setText(item.getName());

            holder.linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    abrirDialog(item);
                }
            });

    }

    @Override
    public int getItemCount() { return mUserList.size(); }

    public static class ViewHolder extends RecyclerView.ViewHolder{

        protected TextView txtName;
        protected LinearLayout linearLayout;

        public ViewHolder (View itemView){
            super(itemView);

            txtName = (TextView) itemView.findViewById(R.id.txtName);
            linearLayout = (LinearLayout) itemView.findViewById(R.id.linearLayout);

        }
    }

    private void abrirDialog(final User user){

        mDatabase = FirebaseDatabase.getInstance().getReference();

        dialog = new Dialog(context);

        dialog.setContentView(R.layout.alert_update_status_user);

        Button btnDelete = dialog.findViewById(R.id.btnDelete);
        Button btnOk = dialog.findViewById(R.id.btnOk);

        TextView txtName = dialog.findViewById(R.id.txtName);
        TextView txtPassword = dialog.findViewById(R.id.txtPassword);
        TextView txtEmail = dialog.findViewById(R.id.txtEmail);
        TextView txtPhone = dialog.findViewById(R.id.txtPhone);
        TextView txtCel = dialog.findViewById(R.id.txtCel);
        TextView txtCPF = dialog.findViewById(R.id.txtCPF);
        TextView txtCity = dialog.findViewById(R.id.txtCity);

        txtName.setText(user.getName().toString());
        txtPassword.setText(user.getPassword().toString());
        txtEmail.setText(user.getEmail().toString());
        txtPhone.setText(user.getPhone().toString());
        txtCel.setText(user.getCel().toString());
        txtCPF.setText(user.getCPF().toString());
        txtCity.setText(user.getCity().toString());

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDatabase.child("users").child(user.getKeyUser()).removeValue();
                dialog.dismiss();
            }
        });

        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

}
