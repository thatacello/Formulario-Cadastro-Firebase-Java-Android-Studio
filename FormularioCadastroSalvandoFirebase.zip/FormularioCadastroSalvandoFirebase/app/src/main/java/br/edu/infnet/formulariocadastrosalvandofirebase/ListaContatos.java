package br.edu.infnet.formulariocadastrosalvandofirebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ListaContatos extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private Adapter adapter;
    private List<User> adapterList;
    private User user;
    private LinearLayoutManager mLinearLayoutManager;
    private DatabaseReference reference;

   @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_contatos);

       mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);

       popularListaContatos();
       
    }

    private void popularListaContatos(){

        mRecyclerView.setHasFixedSize(true);

        mLinearLayoutManager = new LinearLayoutManager(ListaContatos.this, LinearLayoutManager.VERTICAL, false);

        mRecyclerView.setLayoutManager(mLinearLayoutManager);

        adapterList = new ArrayList<>();

        reference = FirebaseDatabase.getInstance().getReference();

        reference.child("users").orderByChild("name").addValueEventListener(new ValueEventListener(){
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                adapterList.clear();

                for (DataSnapshot commitmentSnapshot : dataSnapshot.getChildren()){
                    user = commitmentSnapshot.getValue(User.class);

                    adapterList.add(user);

                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        adapter = new Adapter(adapterList, ListaContatos.this);
        mRecyclerView.setAdapter(adapter);


    }


}
